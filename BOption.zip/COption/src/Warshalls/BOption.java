/*
 * Author: Miriam Ekiye
 * Date: 2/9/2020
 * The program is run here in the main method and the size of the metric is entered here as well as the vaues of the BMR.
 */
package Warshalls;

import java.util.Scanner;

/**
 *
 * @author Miriam
 */
public class BOption {

     
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner sc = new Scanner(System.in);       
        System.out.println("Enter the size of the array for the BMR: ");
        int size = sc.nextInt();
         
         boolean[][] bmr = new boolean[size][size];
         System.out.println(" Enter the data the metrixs contains ");
         for(int i = 0; i < size; i++)
         {
             for(int j = 0; j<size; j++)
             {
                 bmr[i][j] = sc.nextBoolean();
             }
         }
         
                
         //calling the methods of the class and entering the data so the algorithm will be computed
         TransitiveClosureB transitiveClosure = new TransitiveClosureB(bmr);
        OutputVal fileOutput = new OutputVal(transitiveClosure.closure(), bmr);
        fileOutput.fileOutput();
        
        
    }
}
