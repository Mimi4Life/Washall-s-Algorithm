/*
 * Author: Miram Ekiye
 * Date: 2/9/2020
 * The pupose of this method is to read the user's input for the BMR metrics 
 * then it will also print out the transitive closure ina tabular form
 */
package Warshalls;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author Miriam
 */
public class OutputVal {
//Gets the size, Transitive Closure and BMR and is used in displaying the output
    private boolean[][] tClosure;
    private int size;
    private boolean[][] bmr;
   
    
   public OutputVal( boolean[][] tClosure, boolean[][] bmr){
        this.tClosure = tClosure;
        this.size = tClosure.length;
        this.bmr = bmr;
    }
    
    
    public void fileOutput(){
        String str = "ABCDJKL";
     try{
            
            FileWriter fw = new FileWriter("OutputVal.txt");
         try (PrintWriter pw = new PrintWriter(fw)) {
            //Displays the data entered by user in Metric form
            
             pw.println(" ");
             pw.println(" User input Matrix ");
             for(int v = 0; v < size; v++)
             {
                 for(int w = 0; w < size; w++)
                 {
                     pw.print(" "+bmr[v][w]+" ");
                 }
                 pw.println();
             }
             pw.println(" ");
             //Displays the Transitive closure computed
              pw.println(" Warshalls Algorithm output " );
             for(int v = 0; v < size; v++)
                 pw.print("   "+ str.charAt(v));
             pw.println();
             for(int v = 0; v < size; v++)
             {
                 pw.print(str.charAt(v) +" " );
                 for(int w = 0; w < size; w++)
                 {
                     if(tClosure[v][w])
                         pw.print(" 1  ");
                     else
                         pw.print(" 0  ");
                 }
                 pw.println();
             } }
       
      }catch(IOException e){
          System.out.println("An error occrred! ");
      }
 }
    
    
    
}
