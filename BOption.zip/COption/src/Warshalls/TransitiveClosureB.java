/*
 * Author: Miriam Ekiye
 * Date: 2/9/2020
 * This is a seperate class where Warshalls algorith is used for the transitive closure
 */
package Warshalls;

/**
 *
 * @author Miriam
 */
public class TransitiveClosureB {
    private boolean bmr[][];
    private boolean[][] tClosure;
    private int size;
    
    public TransitiveClosureB( boolean bmr[][]) {
        this.bmr = bmr;
    }
    
    public boolean[][] closure() {
        this.size = bmr.length;
      tClosure = new boolean[size][size];
      boolean trueA = true;
      boolean falseB = false;
      for(int i = 0; i< size; i++)
      {
          for(int j = 0; j< size; j++)
              if(bmr[i][j])
                tClosure[i][j] = true;
             tClosure[i][i] = true;
      }
      
      for(int i = 0; i<size; i++)
      {
          for(int j=0; j < size; j++)
          {
              if(tClosure[j][i])
                  for(int k = 0; k <size; k++)
                      if(tClosure[j][i] && tClosure[i][k])
                            tClosure[j][k] = true;
        
           }
      }
      return tClosure;
    }
}
